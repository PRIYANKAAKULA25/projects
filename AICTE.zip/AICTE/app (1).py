import os
import pickle
import streamlit as st
from streamlit_option_menu import option_menu

# Set Streamlit page configuration
st.set_page_config(page_title="Prediction of Disease Outbreaks",
                   layout="wide",
                   page_icon="🧑‍⚕️")

# Ensure working directory is set correctly
working_dir = os.path.dirname(os.path.abspath(__file__))

# Paths to saved models
diabetes_model_path = os.path.join(working_dir, 'saved_models', 'diabetes_model.sav')
heart_disease_model_path = os.path.join(working_dir, 'saved_models', 'heart_disease_model.sav')
parkinsons_model_path = os.path.join(working_dir, 'saved_models', 'parkinsons_model.sav')

# Load models with error handling
try:
    diabetes_model = pickle.load(open(diabetes_model_path, 'rb'))
    heart_disease_model = pickle.load(open(heart_disease_model_path, 'rb'))
    parkinsons_model = pickle.load(open(parkinsons_model_path, 'rb'))
except Exception as e:
    st.error(f"Error loading models: {e}")
    st.stop()

# Sidebar navigation
with st.sidebar:
    selected = option_menu('Disease Prediction System',
                           ['Diabetes Prediction',
                            'Heart Disease Prediction',
                            'Parkinsons Prediction'],
                           menu_icon='hospital-fill',
                           icons=['activity', 'heart', 'person'],
                           default_index=0)

# Diabetes Prediction Page
if selected == 'Diabetes Prediction':
    st.title('Diabetes Prediction using ML')
    
    # Input fields
    inputs = {
        'Pregnancies': st.text_input('Number of Pregnancies'),
        'Glucose': st.text_input('Glucose Level'),
        'BloodPressure': st.text_input('Blood Pressure value'),
        'SkinThickness': st.text_input('Skin Thickness value'),
        'Insulin': st.text_input('Insulin Level'),
        'BMI': st.text_input('BMI value'),
        'DiabetesPedigreeFunction': st.text_input('Diabetes Pedigree Function value'),
        'Age': st.text_input('Age of the Person')
    }
    
    # Predict button
    if st.button('Diabetes Test Result'):
        try:
            user_input = [float(inputs[key]) for key in inputs]
            prediction = diabetes_model.predict([user_input])[0]
            result = 'The person is diabetic' if prediction == 1 else 'The person is not diabetic'
            st.success(result)
        except Exception as e:
            st.error(f"Error in prediction: {e}")

# Repeat similar structure for Heart Disease and Parkinson's Prediction

# Heart Disease Prediction Page
if selected == 'Heart Disease Prediction':
    st.title('Heart Disease Prediction using ML')
    # Input fields and prediction logic here (similar to above)

# Parkinson's Prediction Page
if selected == "Parkinsons Prediction":
    st.title("Parkinson's Disease Prediction using ML")
    # Input fields and prediction logic here (similar to above)
